
# 📰 Exposing the Truth with Advanced Fake News Detection Powered by Natural Language Processing

## 🧠 Overview
This project utilizes advanced Natural Language Processing (NLP) techniques to detect and classify fake news articles based on their content. With misinformation spreading rapidly across digital platforms, the goal is to develop a reliable AI-powered system that helps users and platforms verify the authenticity of news sources.

## 🎯 Objectives
- Analyze news content using NLP to detect misleading or fake news.
- Use machine learning models to classify articles as fake or real.
- Support public awareness and fact-checking efforts through automation.

## 📂 Dataset
- Sourced from publicly available fake news datasets such as Kaggle’s “Fake and Real News Dataset.”
- Dataset includes:
  - News titles and body text
  - Labels (Fake / Real)

📁 Sample data file: dataset.csv

## 🤖 Machine Learning Techniques
- Text Preprocessing (tokenization, stopword removal, stemming)
- TF-IDF vectorization for feature extraction
- Classification Models:
  - Logistic Regression
  - Support Vector Machine (SVM)
  - Random Forest Classifier
  - Passive Aggressive Classifier

## 🔬 Tools & Technologies
- Python 3
- Google Colab for cloud-based development
- Pandas, NumPy for data handling
- Scikit-learn for ML models
- NLTK / SpaCy for NLP preprocessing
- Matplotlib / Seaborn for visualization

## 📊 Results
- Achieved up to 95% accuracy using SVM and Passive Aggressive Classifier.
- Evaluated using:
  - Confusion matrix
  - Precision, Recall, and F1-score

📝 Detailed results available in Output(Google Colab Impl).pdf

## 🚀 Deployment
- Model implemented and tested in Google Colab.
- Future scope: Integrate with web platforms for real-time article screening.



## 👥 Team Members
Developed as part of the Naan Mudhalvan program by:
- S. Pavankumar  
- Naveen R.  
- Navinesh B.  
- Perumalsamy R.P  
- Surieyaa S.  
- Sri Latchmana Ganapathy  
- Syed Aadhil  
- Chenchu Raja



## 🔮 Future Enhancements
- Incorporate real-time scraping and fact-check APIs.
- Deploy as a browser extension or web dashboard.
- Expand to multilingual fake news detection.
